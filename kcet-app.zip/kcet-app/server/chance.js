// Turns a model prediction into an admission chance.
// The model predicts log(cutoff). Its test-set error is roughly normal on the log scale with
// standard deviation `sigma`, so:  P(admitted) = P(actual cutoff >= student rank)
//                                             = 1 - Phi((ln(rank) - ln(predicted)) / sigma)

// Abramowitz & Stegun 7.1.26 approximation of erf (max error ~1.5e-7)
function erf(x) {
  const s = Math.sign(x); x = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * x);
  const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
  return s * y;
}
export const normCdf = (z) => 0.5 * (1 + erf(z / Math.SQRT2));

export function chance(rank, predicted, sigma) {
  return 1 - normCdf((Math.log(rank) - Math.log(predicted)) / sigma);
}

export function verdict(p) {
  if (p >= 0.7) return 'likely';
  if (p >= 0.3) return 'borderline';
  return 'unlikely';
}

// ~68% band around the prediction (one sigma either side on the log scale)
export function band(predicted, sigma) {
  return [Math.round(predicted * Math.exp(-sigma)), Math.round(predicted * Math.exp(sigma))];
}
