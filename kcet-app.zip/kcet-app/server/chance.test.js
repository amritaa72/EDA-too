import test from 'node:test';
import assert from 'node:assert/strict';
import { chance, normCdf, verdict, band } from './chance.js';

test('normCdf basics', () => {
  assert.ok(Math.abs(normCdf(0) - 0.5) < 1e-6);
  assert.ok(Math.abs(normCdf(1.96) - 0.975) < 1e-3);
});
test('rank equal to predicted cutoff is a coin flip', () => {
  assert.ok(Math.abs(chance(5000, 5000, 0.26) - 0.5) < 1e-6);
});
test('better rank -> higher chance, monotonic', () => {
  assert.ok(chance(3000, 5000, 0.26) > chance(5000, 5000, 0.26));
  assert.ok(chance(5000, 5000, 0.26) > chance(9000, 5000, 0.26));
});
test('verdict thresholds', () => {
  assert.equal(verdict(0.8), 'likely');
  assert.equal(verdict(0.5), 'borderline');
  assert.equal(verdict(0.1), 'unlikely');
});
test('band brackets the prediction', () => {
  const [lo, hi] = band(10000, 0.26);
  assert.ok(lo < 10000 && hi > 10000);
});
