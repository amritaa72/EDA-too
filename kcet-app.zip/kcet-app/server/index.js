import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chance, verdict, band } from './chance.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'predictions.json'), 'utf8'));
const { seats, sigma } = data;

const ORDER = ['GM','GMK','GMR','1G','1K','1R','2AG','2AK','2AR','2BG','2BK','2BR','3AG','3AK','3AR','3BG','3BK','3BR','SCG','SCK','SCR','STG','STK','STR'];
const BASE = { GM: 'General Merit', '1': 'Category 1', '2A': 'Category 2A', '2B': 'Category 2B', '3A': 'Category 3A', '3B': 'Category 3B', SC: 'Scheduled Caste', ST: 'Scheduled Tribe' };
const SUFFIX = { G: '', K: ' – Kannada medium', R: ' – Rural' };
function categoryLabel(code) {
  if (code === 'GM') return BASE.GM;
  if (code.startsWith('GM')) return BASE.GM + SUFFIX[code.slice(2)];
  return BASE[code.slice(0, -1)] + SUFFIX[code.slice(-1)];
}

const categories = ORDER.filter((c) => seats.some((s) => s.category === c))
  .map((code) => ({ code, label: `${code} · ${categoryLabel(code)}` }));
const branches = [...new Set(seats.map((s) => s.branch))].sort();

const find = (q) => seats.find((s) => s.college_code === q.college && s.branch === q.branch && s.category === q.category);

function describe(seat, rank) {
  const p = chance(rank, seat.pred_2026, sigma);
  return { ...seat, chance: Math.round(p * 1000) / 10, verdict: verdict(p), band: band(seat.pred_2026, sigma) };
}

function parseRank(v) {
  const n = Number(v);
  return Number.isInteger(n) && n >= 1 && n <= 400000 ? n : null;
}
const BAD_RANK = { error: 'Enter your KCET rank as a whole number (1 – 400000).' };

const app = express();
app.disable('x-powered-by');

app.get('/api/meta', (_req, res) => {
  res.json({
    categories, branches,
    collegeCount: new Set(seats.map((s) => s.college_code)).size,
    model: { name: data.model, sigma, trainPairs: data.trainPairs, testPairs: data.testPairs,
             medianPctError: data.medianPctError, baselinePctError: data.baselinePctError },
  });
});

// colleges offering a seat in this category (optionally for one branch)
app.get('/api/colleges', (req, res) => {
  const { category, branch } = req.query;
  const m = new Map();
  for (const s of seats) {
    if (category && s.category !== category) continue;
    if (branch && s.branch !== branch) continue;
    m.set(s.college_code, s.college_name);
  }
  res.json([...m].map(([code, name]) => ({ code, name })).sort((a, b) => a.name.localeCompare(b.name)));
});

app.get('/api/branches', (req, res) => {
  const { college, category } = req.query;
  res.json(seats.filter((s) => s.college_code === college && s.category === category).map((s) => s.branch).sort());
});

app.get('/api/predict', (req, res) => {
  const rank = parseRank(req.query.rank);
  if (rank === null) return res.status(400).json(BAD_RANK);
  const seat = find(req.query);
  if (!seat) return res.status(404).json({ error: 'No cutoff data for that college, branch and category.' });
  res.json(describe(seat, rank));
});

// "What can I get?": every college offering a branch, most competitive first
app.get('/api/explore', (req, res) => {
  const rank = parseRank(req.query.rank);
  if (rank === null) return res.status(400).json(BAD_RANK);
  const { branch, category } = req.query;
  res.json(seats.filter((s) => s.branch === branch && s.category === category)
    .map((s) => describe(s, rank)).sort((a, b) => a.pred_2026 - b.pred_2026));
});

const dist = path.join(__dirname, '..', 'client', 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`KCET predictor on http://localhost:${PORT}  (${seats.length} seats loaded)`));
