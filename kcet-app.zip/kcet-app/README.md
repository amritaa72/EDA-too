# KCET Seat Predictor (Node + React)

Pick a college and branch, enter your rank and category, and see your estimated chance of getting that seat in 2026.
A second tab lists the colleges you could realistically get for a branch, grouped as Likely / Borderline / Reach.

## Run it

```bash
npm install            # server dependency (express)
npm run build          # installs + builds the React client into client/dist
npm start              # open http://localhost:3001
npm test               # unit tests for the chance calculation
```

Development with hot reload (two terminals):

```bash
npm run dev                          # API on :3001
cd client && npm install && npm run dev   # React on :5173 (proxies /api to :3001)
```

## How it works

```
PDFs --extract.py/clean.py--> kcet_tidy.csv --train.py--> server/data/predictions.json
                                                              |
                                          Express API (server/) -- React app (client/)
```

* **Problem type:** regression. Target = how much a seat's cutoff moved from 2024 to 2025 (log scale).
* **Features:** previous cutoff rank, category, branch group. 80/20 train/test split.
* **Models compared:** "no change" baseline, Ridge regression, Random forest (the best on the test set is used).
* **Prediction:** the 2025 cutoff is fed in, giving a 2026 estimate for every seat.
* **Chance %:** the test-set error is roughly normal on the log scale (std = `sigma`), so
  `chance = 1 - Phi((ln(rank) - ln(predicted cutoff)) / sigma)` (see `server/chance.js`).

## Retrain

```bash
cd ml
pip install pandas scikit-learn scipy joblib
python train.py        # reads kcet_tidy.csv, rewrites ../server/data/predictions.json
```

`extract.py` / `clean.py` rebuild `kcet_tidy.csv` from the four KEA PDFs (edit the `UP` path at the top of `extract.py`).

## Limits

* Only two years of General Merit data. The model learns one year-to-year change, not a long-term trend.
* Seats with a cutoff under about 5,000 are no more predictable than "same as last year".
* Branch names differ between years, so they are matched through a `branch_group` column (see `clean.py`).
* This is a guide, not an official allotment prediction.
