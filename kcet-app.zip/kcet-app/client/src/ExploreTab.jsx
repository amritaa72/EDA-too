import React, { useState } from 'react';
import { api, fmt, fmtChance } from './api.js';

function Group({ title, hint, items, limit }) {
  const [all, setAll] = useState(false);
  if (!items.length) return null;
  const shown = all ? items : items.slice(0, limit);
  return (
    <section className="card">
      <h3>{title} <span className="muted small">({items.length})</span></h3>
      <p className="muted small">{hint}</p>
      <ul className="rows">
        {shown.map((s) => (
          <li key={s.college_code}>
            <div><strong>{s.college_name}</strong><span className="muted small">2025 cutoff {fmt(s.rank_2025)} · 2026 estimate {fmt(s.pred_2026)}</span></div>
            <span className={`pill ${s.verdict}`}>{fmtChance(s.chance)}</span>
          </li>
        ))}
      </ul>
      {items.length > limit && <button className="link" onClick={() => setAll(!all)}>{all ? 'Show fewer' : `Show all ${items.length}`}</button>}
    </section>
  );
}

export default function ExploreTab({ meta }) {
  const [rank, setRank] = useState('');
  const [category, setCategory] = useState('GM');
  const [branch, setBranch] = useState('Computer Science & Engg');
  const [list, setList] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault(); setError(''); setList(null);
    if (!rank) return setError('Enter your KCET rank.');
    setBusy(true);
    try { setList(await api('explore', { rank, category, branch })); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }

  const likely = list?.filter((s) => s.verdict === 'likely') ?? [];
  const border = list?.filter((s) => s.verdict === 'borderline') ?? [];
  const reach = (list?.filter((s) => s.verdict === 'unlikely' && s.chance >= 3) ?? []).sort((a, b) => b.chance - a.chance);

  return (
    <>
      <form className="card form" onSubmit={submit}>
        <label>Your KCET rank
          <input type="number" inputMode="numeric" min="1" value={rank} placeholder="e.g. 12000" onChange={(e) => setRank(e.target.value)} />
        </label>
        <label>Your category
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {meta.categories.map((c) => <option key={c.code} value={c.code}>{c.label}</option>)}
          </select>
        </label>
        <label>Branch you want
          <select value={branch} onChange={(e) => setBranch(e.target.value)}>
            {meta.branches.map((b) => <option key={b}>{b}</option>)}
          </select>
        </label>
        <button disabled={busy}>{busy ? 'Searching…' : 'Find colleges for me'}</button>
      </form>
      {error && <p className="error" role="alert">{error}</p>}
      {list && !list.length && <p className="muted">No colleges have data for that branch and category.</p>}
      {list && <>
        <Group title="Reach" hint="Less than 30% chance, but possible. Closest first." items={reach} limit={8} />
        <Group title="Borderline" hint="30–70% chance. Worth listing in your options." items={border} limit={10} />
        <Group title="Likely" hint="70%+ chance. Most competitive colleges first." items={likely} limit={10} />
        {!likely.length && !border.length && !reach.length && <p className="muted">No realistic options for this rank in that branch and category.</p>}
      </>}
    </>
  );
}
