import React from 'react';
import RankMeter from './RankMeter.jsx';
import { fmt, fmtChance, VERDICT_TEXT } from './api.js';

export default function ResultCard({ r, rank, sigma }) {
  return (
    <section className={`card result ${r.verdict}`} aria-live="polite">
      <header>
        <div>
          <h2>{r.college_name}</h2>
          <p className="muted">{r.branch} · {r.category}</p>
        </div>
        <div className="chance">
          <strong>{fmtChance(r.chance)}</strong>
          <span className={`badge ${r.verdict}`}>{VERDICT_TEXT[r.verdict]}</span>
        </div>
      </header>

      <RankMeter rank={rank} predicted={r.pred_2026} sigma={sigma} />

      <table className="cutoffs">
        <thead><tr><th>2024 cutoff</th><th>2025 cutoff</th><th>2026 estimate</th><th>Your rank</th></tr></thead>
        <tbody>
          <tr>
            <td>{fmt(r.rank_2024)}</td>
            <td>{fmt(r.rank_2025)}</td>
            <td className="est">{fmt(r.pred_2026)}<small>likely {fmt(r.band[0])} – {fmt(r.band[1])}</small></td>
            <td>{fmt(rank)}</td>
          </tr>
        </tbody>
      </table>

      <p className="muted small">
        {rank <= r.pred_2026
          ? `Your rank is ${fmt(r.pred_2026 - rank)} places better than the estimated 2026 cutoff.`
          : `Your rank is ${fmt(rank - r.pred_2026)} places behind the estimated 2026 cutoff.`}
        {r.rank_2024 == null && ' This seat had no 2024 data, so the estimate rests on 2025 alone.'}
      </p>
    </section>
  );
}
