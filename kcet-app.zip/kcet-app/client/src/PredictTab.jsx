import React, { useEffect, useState } from 'react';
import { api } from './api.js';
import ResultCard from './ResultCard.jsx';

export default function PredictTab({ meta }) {
  const [rank, setRank] = useState('');
  const [category, setCategory] = useState('GM');
  const [colleges, setColleges] = useState([]);
  const [collegeText, setCollegeText] = useState('');
  const [branches, setBranches] = useState([]);
  const [branch, setBranch] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const optionLabel = (c) => `${c.code} · ${c.name}`;
  const college = colleges.find((c) => optionLabel(c) === collegeText);

  // category changes -> reload the list of colleges that have seats in it
  useEffect(() => {
    setCollegeText(''); setBranches([]); setBranch(''); setResult(null);
    api('colleges', { category }).then(setColleges).catch((e) => setError(e.message));
  }, [category]);

  // a college was chosen -> load the branches it offers for this category
  useEffect(() => {
    setBranch(''); setResult(null);
    if (!college) { setBranches([]); return; }
    api('branches', { college: college.code, category }).then((b) => { setBranches(b); if (b.length === 1) setBranch(b[0]); });
  }, [college?.code]);

  async function submit(e) {
    e.preventDefault();
    setError(''); setResult(null);
    if (!rank) return setError('Enter your KCET rank.');
    if (!college) return setError('Pick a college from the list.');
    if (!branch) return setError('Pick a branch.');
    setBusy(true);
    try { setResult(await api('predict', { rank, college: college.code, branch, category })); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }

  return (
    <>
      <form className="card form" onSubmit={submit}>
        <label>Your KCET rank
          <input type="number" inputMode="numeric" min="1" value={rank} placeholder="e.g. 4500"
                 onChange={(e) => setRank(e.target.value)} />
        </label>
        <label>Your category
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {meta.categories.map((c) => <option key={c.code} value={c.code}>{c.label}</option>)}
          </select>
        </label>
        <label>College
          <input list="colleges" value={collegeText} placeholder="Start typing a college name or code"
                 onChange={(e) => setCollegeText(e.target.value)} />
          <datalist id="colleges">
            {colleges.map((c) => <option key={c.code} value={optionLabel(c)} />)}
          </datalist>
        </label>
        <label>Branch
          <select value={branch} onChange={(e) => setBranch(e.target.value)} disabled={!branches.length}>
            <option value="">{college ? 'Select a branch' : 'Choose a college first'}</option>
            {branches.map((b) => <option key={b} value={b}>{b}</option>)}
          </select>
        </label>
        <button disabled={busy}>{busy ? 'Calculating…' : 'Check my chances'}</button>
      </form>
      {error && <p className="error" role="alert">{error}</p>}
      {result && <ResultCard r={result} rank={Number(rank)} sigma={meta.model.sigma} />}
    </>
  );
}
