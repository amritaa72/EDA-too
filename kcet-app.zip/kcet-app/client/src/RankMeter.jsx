import React from 'react';

// Shows where the student's rank sits relative to the predicted cutoff, on a log scale.
// Left = better rank (safe), right = worse rank (cutoff will probably be passed).
export default function RankMeter({ rank, predicted, sigma }) {
  const lo = Math.log(predicted) - 2.5 * sigma;
  const hi = Math.log(predicted) + 2.5 * sigma;
  const pos = Math.min(1, Math.max(0, (Math.log(rank) - lo) / (hi - lo))) * 100;
  return (
    <div className="meter" role="img" aria-label="Your rank compared with the predicted cutoff">
      <div className="meter-bar">
        <span className="meter-tick" style={{ left: '50%' }} />
        <span className="meter-marker" style={{ left: `${pos}%` }} />
      </div>
      <div className="meter-labels">
        <span>Safer</span>
        <span>Predicted cutoff</span>
        <span>Riskier</span>
      </div>
    </div>
  );
}
