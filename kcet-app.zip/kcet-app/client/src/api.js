export async function api(path, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const res = await fetch(`/api/${path}${qs ? `?${qs}` : ''}`);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || `Request failed (${res.status})`);
  return body;
}

export const fmt = (n) => (n == null ? '—' : Number(n).toLocaleString('en-IN'));
export const fmtChance = (c) => (c < 1 ? '<1%' : c > 99 ? '>99%' : `${Math.round(c)}%`);
export const VERDICT_TEXT = { likely: 'Likely', borderline: 'Borderline', unlikely: 'Unlikely' };
