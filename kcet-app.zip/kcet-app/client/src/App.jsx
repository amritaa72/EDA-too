import React, { useEffect, useState } from 'react';
import { api } from './api.js';
import PredictTab from './PredictTab.jsx';
import ExploreTab from './ExploreTab.jsx';

export default function App() {
  const [meta, setMeta] = useState(null);
  const [tab, setTab] = useState('predict');
  const [error, setError] = useState('');

  useEffect(() => { api('meta').then(setMeta).catch((e) => setError(e.message)); }, []);

  return (
    <main>
      <header className="top">
        <h1>KCET Seat Predictor</h1>
        <p className="muted">Pick a college and branch to see your chance of getting it in 2026, estimated from the 2024 and 2025 cutoff ranks.</p>
      </header>

      <nav className="tabs" role="tablist">
        <button role="tab" aria-selected={tab === 'predict'} onClick={() => setTab('predict')}>I know my college</button>
        <button role="tab" aria-selected={tab === 'explore'} onClick={() => setTab('explore')}>Find colleges for my rank</button>
      </nav>

      {error && <p className="error">Could not reach the server: {error}</p>}
      {!meta && !error && <p className="muted">Loading…</p>}
      {meta && (tab === 'predict' ? <PredictTab meta={meta} /> : <ExploreTab meta={meta} />)}

      {meta && (
        <footer className="muted small">
          <p><strong>How reliable is this?</strong> A {meta.model.name.toLowerCase()} learned how cutoffs moved from 2024 to 2025
            across {meta.model.trainPairs.toLocaleString('en-IN')} seats and was tested on {meta.model.testPairs.toLocaleString('en-IN')} unseen ones.
            Its typical error is about {Math.round(meta.model.medianPctError)}% of the cutoff rank (assuming no change would be off by
            about {Math.round(meta.model.baselinePctError)}%). Top-ranked seats (cutoff under 5,000) are the least predictable.</p>
          <p>Only two years of general-merit data were used, so treat results as a guide, not a guarantee. Check official KEA notifications before making choices.</p>
        </footer>
      )}
    </main>
  );
}
