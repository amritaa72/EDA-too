import re, sys, collections
import pdfplumber, pandas as pd

UP = "/mnt/user-data/uploads/"
FILES = [("2024-1-GEN.pdf", 2024, 1), ("2024-2-GEN.pdf", 2024, 2),
         ("2025-1-GEN.pdf", 2025, 1), ("2025-2-GEN.pdf", 2025, 2)]
CAT = re.compile(r"^(1|2A|2B|3A|3B|GM|SC|ST|NRI|OPN|OTH)[A-Z]?$")
NUM = re.compile(r"^\d+(\.\d+)?$")

ISNUM = lambda x: bool(re.fullmatch(r"[\d.]+|--", x))

def cluster_lines(items, tol=2.5):
    items = sorted(items, key=lambda w: (w["top"], w["x0"]))
    lines = []
    for w in items:
        if lines and abs(w["top"] - lines[-1][0]["top"]) <= tol:
            lines[-1].append(w)
        else:
            lines.append([w])
    return [sorted(l, key=lambda w: w["x0"]) for l in lines]

def assign(cols, xc):
    return min(cols, key=lambda c: abs(c[1] - xc))[0]

# ---------------- 2024 (monospaced, values can fuse) ----------------
def parse_2024(path, year, rnd):
    out = []
    with pdfplumber.open(path) as pdf:
        college = None; cols = None; cur = None
        for page in pdf.pages:
            chars = [c for c in page.chars if c["text"].strip()]
            # words for structure
            words = page.extract_words()
            lines = cluster_lines(words)
            cline = {}
            for c in chars: cline.setdefault(round(c["top"]), []).append(c)
            ckeys = sorted(cline)
            def chars_for(top):
                k = min(ckeys, key=lambda t: abs(t - top))
                return sorted(cline[k], key=lambda c: c["x0"])
            for ln in lines:
                t = [w["text"] for w in ln]
                top = ln[0]["top"]
                if len(t) > 2 and re.fullmatch(r"\d+", t[0]) and re.fullmatch(r"E\d{3}", t[1]) and ln[0]["x0"] < 100:
                    college = (t[1], " ".join(t[2:])); cur = None; continue
                if t and all(CAT.match(x) for x in t) and len(t) >= 10:
                    cols = [(w["text"], (w["x0"] + w["x1"]) / 2) for w in ln]; cur = None; continue
                if "ENGINEERING CUTOFF" in " ".join(t) or re.match(r"\d\d-[A-Z]{3}-\d\d", t[0]): continue
                if college is None or cols is None: continue
                # branch row: starts with 2-letter code at left and has value columns
                if re.fullmatch(r"[A-Z]{2}", t[0]) and ln[0]["x0"] < 100 and len(t) > 3:
                    code = t[0]
                    name = [w["text"] for w in ln[1:] if not ISNUM(w["text"])]
                    vals = {c: [] for c, _ in cols}
                    lc = chars_for(top)
                    for w in ln:
                        if not ISNUM(w["text"]): continue
                        for ch in lc:
                            if ch["x0"] >= w["x0"] - 0.5 and ch["x1"] <= w["x1"] + 0.5:
                                vals[assign(cols, (ch["x0"] + ch["x1"]) / 2)].append(ch["text"])
                    cur = dict(year=year, round=rnd, college_code=college[0], college_name=college[1],
                               branch_code=code, branch_name=name, vals={k: "".join(v) for k, v in vals.items()})
                    out.append(cur)
                elif cur is not None and ln[0]["x0"] < 110:
                    cur["branch_name"] += t   # wrapped continuation of branch name
    return out

# ---------------- 2025 (proportional, tokens separated) ----------------
def parse_2025(path, year, rnd):
    out = []
    with pdfplumber.open(path) as pdf:
        college = None; cols = None; cur = None
        for page in pdf.pages:
            for ln in cluster_lines(page.extract_words()):
                t = [w["text"] for w in ln]
                if t[0] == "College:" :
                    college = (t[1], " ".join(t[2:])); cur = None; continue
                if t[:2] == ["Course", "Name"]:
                    cols = [(w["text"], (w["x0"] + w["x1"]) / 2) for w in ln[2:]]; cur = None; continue
                if college is None or cols is None: continue
                if t[0] in ("Generated", "Seat", "KARNATAKA", "Non-Interactive", "UGCET-2025") or "Page" in t: continue
                valtoks = [w for w in ln if ISNUM(w["text"])]
                nametoks = [w["text"] for w in ln if not ISNUM(w["text"])]
                if len(valtoks) >= 5:
                    vals = {c: "" for c, _ in cols}
                    for w in valtoks: vals[assign(cols, (w["x0"] + w["x1"]) / 2)] = w["text"]
                    cur = dict(year=year, round=rnd, college_code=college[0], college_name=college[1],
                               branch_code="", branch_name=nametoks, vals=vals)
                    out.append(cur)
                elif cur is not None and nametoks and not valtoks:
                    cur["branch_name"] += nametoks
    return out

rows = []
for f, y, r in FILES:
    recs = (parse_2024 if y == 2024 else parse_2025)(UP + f, y, r)
    print(f, "branch-rows:", len(recs), "colleges:", len({x['college_code'] for x in recs}))
    for x in recs:
        for cat, v in x["vals"].items():
            rows.append(dict(year=x["year"], round=x["round"], college_code=x["college_code"],
                             college_name=x["college_name"], branch_code=x["branch_code"],
                             branch_name_raw=" ".join(x["branch_name"]), category=cat, cutoff_raw=v))
df = pd.DataFrame(rows)
df.to_csv("raw_long.csv", index=False)
print(df.shape)
