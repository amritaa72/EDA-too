import re, pandas as pd, numpy as np
df = pd.read_csv("raw_long.csv", dtype=str, keep_default_na=False)

# ---- repair names broken by PDF line-wrapping ("COMMUNICATIO N") ----
def key(s): return re.sub(r"[^a-z0-9]", "", s.lower())
df["_k"] = df.branch_name_raw.map(key)
def tidy_name(s):
    return re.sub(r"\s+", " ", s).strip()
df["_n"] = df.branch_name_raw.map(tidy_name)
def frag(s): return sum(len(w) <= 2 and w.isalpha() and w.upper() not in {"IN","OF","AI","ML","IT","CS","EC","EE","ME","CE","B","AND"} for w in s.split())
cnt = df.groupby(["_k","_n"]).size().reset_index(name="c")
cnt["f"] = cnt._n.map(frag)
cand = cnt.sort_values(["_k","f","c"], ascending=[True, True, False]).drop_duplicates("_k").set_index("_k")._n
df["branch_name"] = df["_k"].map(cand)

# ---- branch groups so 2024 codes and 2025 names can be matched ----
RULES = [
 (r"kannada", None),
 (r"cyber", "CSE (Cyber Security)"),
 (r"iot|internetofthings", "CSE (IoT)"),
 (r"(artificial|ai).*(data|ds)|artificialintel,?datasc|btechinad|^ad$", "AI & Data Science"),
 (r"machine|aiml|artint|artificial|^ai$|btechinai$|csartificial|cs\(ai", "AI & Machine Learning"),
 (r"datasc|btechinds|dataanalytics|datasciences", "CSE (Data Science)"),
 (r"businesssys|busines|btechinbs", "CSE (Business Systems)"),
 (r"computerscienceanddesign|compscandesign|computerscdesign|compscidesi|btechinr", "CSE (Design)"),
 (r"computerengineering|computerandcomm", "Computer Engineering"),
 (r"electronicsand(computer|compute)|electricalandcomput|electronicsandcomput", "Electronics & Computer"),
 (r"telecom", "Electronics & Telecommunication"),
 (r"instrument|elecinst|electronicsinstr", "Electronics & Instrumentation"),
 (r"electricalandelectronics|^electrical|btechinee|electricalengg", "Electrical & Electronics"),
 (r"electronicsandcommunication|electronicscommunication|^electronics$|btechinec|ecengg|electronicsengineering$", "Electronics & Communication"),
 (r"informationscience|infoscience|btechinis|informationtech|btechinit|^informationengineering", "Information Science"),
 (r"computerscience|computers|btechincs|compscience|compsce|compsc|^cs$|csc|computerscienceandengg|computerscienceandtech", "Computer Science & Engg"),
 (r"aero|aeronaut|aerospace", "Aeronautical / Aerospace"),
 (r"mechanical|btechinme", "Mechanical"),
 (r"civil|btechince|construction", "Civil"),
 (r"biotech|bio-?tech|btechinbt", "Biotechnology"),
 (r"biomed|medical", "Biomedical / Medical Electronics"),
 (r"chemical", "Chemical"),
 (r"industrial.*(manage|mgmt)|indengg", "Industrial Engg & Management"),
 (r"industrial.*prod|indprodn", "Industrial & Production"),
 (r"automobile|automotive", "Automobile"),
 (r"robot", "Robotics"),
 (r"agri", "Agriculture"),
 (r"architect|bplan", "Architecture / Planning"),
 (r"environment", "Environmental"),
 (r"mining", "Mining"), (r"marine", "Marine"), (r"polymer", "Polymer"),
 (r"silk", "Silk Technology"), (r"textile", "Textiles"), (r"ceramic", "Ceramics"),
 (r"mechatronics", "Mechatronics"),
]
def group(row):
    txt = key(row.branch_name)
    if row.year == "2024" and re.fullmatch(r"btechin[a-z]{2,3}", txt):
        pass
    for pat, g in RULES:
        if re.search(pat, txt):
            return g or ("Civil (Kannada medium)" if "civil" in txt else "Mechanical (Kannada medium)" if "mech" in txt else "Other")
    return "Other: " + row.branch_name.title()
u = df[["year", "branch_code", "branch_name"]].drop_duplicates()
u["branch_group"] = u.apply(group, axis=1)
df = df.merge(u, on=["year", "branch_code", "branch_name"], how="left")

df["cutoff_rank"] = pd.to_numeric(df.cutoff_raw.replace("--", np.nan), errors="coerce")
df["year"] = df.year.astype(int); df["round"] = df["round"].astype(int)

# ---- college master: short, consistent name per college_code ----
n24 = df[df.year == 2024].groupby("college_code").college_name.first()
n25 = df[df.year == 2025].groupby("college_code").college_name.first()
master = n24.combine_first(n25)
df["college_name"] = df.college_code.map(master).str.replace(r"\s+", " ", regex=True).str.strip()

cols = ["year","round","college_code","college_name","branch_code","branch_name","branch_group","category","cutoff_rank"]
tidy = df[cols].sort_values(["year","round","college_code","branch_code","branch_name","category"]).reset_index(drop=True)
tidy.to_csv("kcet_tidy_all.csv", index=False)           # every row incl. blanks
tidy.dropna(subset=["cutoff_rank"]).to_csv("kcet_tidy.csv", index=False)   # model-ready

# ---- one wide CSV per PDF, mirrors the PDF table ----
order = ["1G","1K","1R","2AG","2AK","2AR","2BG","2BK","2BR","3AG","3AK","3AR","3BG","3BK","3BR","GM","GMK","GMP","GMR","NRI","OPN","OTH","SCG","SCK","SCR","STG","STK","STR"]
for (y, r), g in tidy.groupby(["year","round"]):
    w = (g.groupby(["college_code","college_name","branch_code","branch_name","category"], dropna=False)
           .cutoff_rank.first().unstack("category"))
    w = w[[c for c in order if c in w.columns]].reset_index()
    w.to_csv(f"{y}-{r}-GEN.csv", index=False)
    print(f"{y}-{r}-GEN.csv", w.shape)

m = tidy.dropna(subset=["cutoff_rank"])
print("\ntidy rows:", len(tidy), "| with a rank:", len(m))
print(m.groupby(["year","round"]).size().to_string())
print("\nbranch_group sizes:\n", m.drop_duplicates(["year","college_code","branch_code","branch_name"]).branch_group.value_counts().head(40).to_string())
print("\n'Other' groups:", m[m.branch_group.str.startswith("Other")].branch_name.nunique())
print(sorted(m[m.branch_group.str.startswith("Other")].branch_name.unique())[:40])
