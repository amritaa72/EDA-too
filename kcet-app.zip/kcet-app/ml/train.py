"""Train the KCET cutoff model.
Problem type : regression  (target = next year's cutoff rank, on a log scale)
Features     : previous year's cutoff rank, category, branch group, (college code)
Training data: pairs of (2024 cutoff -> 2025 cutoff) for the same college+branch+category
Prediction   : feed the 2025 cutoff in, get a 2026 estimate out
"""
import os, json, joblib, numpy as np, pandas as pd
from scipy.stats import norm
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

OUT = os.path.join("..", "server", "data", "predictions.json")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

# ---------- 1. build one cutoff per (year, college, branch group, category) ----------
t = pd.read_csv("kcet_tidy.csv", dtype={"branch_code": str}, keep_default_na=False, na_values=[""] if False else None)
t["cutoff_rank"] = pd.to_numeric(t.cutoff_rank, errors="coerce")
t["branch_code"] = t.branch_code.fillna("")
# final cutoff of a seat = the largest rank allotted across rounds
a = (t.groupby(["year", "college_code", "college_name", "branch_code", "branch_name", "branch_group", "category"],
               as_index=False, dropna=False).cutoff_rank.max())
# a college can list the same group more than once -> keep the most competitive one
seats = (a.groupby(["year", "college_code", "branch_group", "category"], as_index=False)
           .agg(cutoff_rank=("cutoff_rank", "min"), branch_name=("branch_name", "first")))
names = t.drop_duplicates("college_code").set_index("college_code").college_name
wide = seats.pivot_table(index=["college_code", "branch_group", "category"], columns="year",
                         values="cutoff_rank").reset_index()
wide.columns = ["college_code", "branch_group", "category"] + [f"rank_{c}" for c in wide.columns[3:]]
wide["college_name"] = wide.college_code.map(names)
wide.to_csv("seat_table.csv", index=False)

# ---------- 2. supervised dataset: 2024 -> 2025 ----------
d = wide.dropna(subset=["rank_2024", "rank_2025"]).copy()
d["log_prev"] = np.log(d.rank_2024)
d["log_next"] = np.log(d.rank_2025)
FEATS = ["log_prev", "category", "branch_group"]
d["log_change"] = d.log_next - d.log_prev      # target: how much the cutoff moved
X, y = d[FEATS], d["log_change"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"pairs: {len(d)}  train: {len(Xtr)}  test: {len(Xte)}")

def make(model):
    pre = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), ["category", "branch_group"])],
                            remainder="passthrough")
    return Pipeline([("pre", pre), ("m", model)])

def report(name, pred_change):
    pred_log = Xte.log_prev.values + pred_change          # back to absolute log rank
    p, a_ = np.exp(pred_log), np.exp(Xte.log_prev.values + yte)
    mape = np.median(np.abs(p - a_) / a_) * 100
    print(f"{name:22s} MAE(rank)={mean_absolute_error(a_, p):9.0f}  median % error={mape:5.1f}  R2(log)={r2_score(Xte.log_prev.values + yte, pred_log):.3f}")
    return mean_absolute_error(yte, pred_change)

# baseline: "next year = this year"
report("baseline (no change)", np.zeros(len(Xte)))
models = {"Ridge regression": make(Ridge(alpha=1.0)),
          "Random forest": make(RandomForestRegressor(n_estimators=300, min_samples_leaf=3, random_state=42, n_jobs=-1))}
scores = {}
for n, m in models.items():
    m.fit(Xtr, ytr); scores[n] = report(n, m.predict(Xte))

best = min(scores, key=scores.get)
print("best on test set:", best)

# ---------- 3. final fit on all pairs + uncertainty ----------
from sklearn.base import clone
resid_te = yte - models[best].predict(Xte)       # honest residuals: model fitted on TRAIN only
test_pred_change = models[best].predict(Xte)
final = clone(models[best]).fit(X, y)             # separate copy refit on all data
sigma = float(np.std(resid_te))
print(f"residual std (log scale): {sigma:.3f}  (~{(np.exp(sigma)-1)*100:.0f}% typical swing)")
joblib.dump({"model": final, "sigma": sigma, "features": FEATS, "model_name": best}, "kcet_model.joblib")
json.dump({"best": best, "sigma": sigma, "n_pairs": len(d), "scores_mae_log": scores}, open("model_info.json", "w"), indent=1)

# ---------- 4. export 2026 predictions for the web app ----------
latest = wide.dropna(subset=["rank_2025"]).copy()
latest["log_prev"] = np.log(latest.rank_2025)
latest["pred_2026"] = np.exp(latest.log_prev + final.predict(latest[FEATS])).round()
def num(v): return None if pd.isna(v) else int(round(v))
seats_out = [dict(college_code=r.college_code, college_name=r.college_name, branch=r.branch_group, category=r.category,
                  rank_2024=num(r.rank_2024), rank_2025=num(r.rank_2025), pred_2026=num(r.pred_2026))
             for r in latest.itertuples()]
actual = np.exp(Xte.log_prev.values + yte); predv = np.exp(Xte.log_prev.values + test_pred_change)
base_mae = float(np.median(np.abs(np.exp(Xte.log_prev.values) - actual) / actual) * 100)
top = actual < 5000
print("top seats (rank<5000) median %% error: model %.1f vs baseline %.1f" % (
      np.median(np.abs(predv[top]-actual[top])/actual[top])*100,
      np.median(np.abs(np.exp(Xte.log_prev.values)[top]-actual[top])/actual[top])*100))
json.dump({"model": best, "sigma": sigma, "trainPairs": len(Xtr), "testPairs": len(Xte),
           "medianPctError": float(np.median(np.abs(predv - actual) / actual) * 100),
           "baselinePctError": base_mae, "seats": seats_out},
          open(OUT, "w"), separators=(",", ":"))
print("exported", len(seats_out), "seats")
